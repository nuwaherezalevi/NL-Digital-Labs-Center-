const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');
menuToggle?.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.setAttribute('aria-label', isOpen ? 'Close navigation menu' : 'Open navigation menu');
  menuToggle.textContent = isOpen ? '×' : '☰';
});
navLinks?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  navLinks.classList.remove('open');
  menuToggle?.setAttribute('aria-expanded', 'false');
  if (menuToggle) { menuToggle.textContent = '☰'; menuToggle.setAttribute('aria-label', 'Open navigation menu'); }
}));
document.getElementById('year').textContent = new Date().getFullYear();

const loginModal = document.getElementById('loginModal');
const closeLogin = document.getElementById('closeLogin');
document.querySelectorAll('[data-open-login]').forEach(button => button.addEventListener('click', () => {
  loginModal.hidden = false;
  document.getElementById('loginEmail').focus();
  document.body.style.overflow = 'hidden';
}));
function hideLogin() {
  loginModal.hidden = true;
  document.body.style.overflow = '';
}
closeLogin.addEventListener('click', hideLogin);
loginModal.addEventListener('click', event => { if (event.target === loginModal) hideLogin(); });
document.addEventListener('keydown', event => { if (event.key === 'Escape' && !loginModal.hidden) hideLogin(); });
document.getElementById('loginForm').addEventListener('submit', event => {
  event.preventDefault();
  document.getElementById('loginStatus').textContent = 'This is a front-end demo. Secure sign-in is not configured yet, so no credentials were sent or saved.';
});

document.querySelectorAll('[data-service]').forEach(link => link.addEventListener('click', () => {
  const serviceSelect = document.getElementById('serviceSelect');
  serviceSelect.value = link.dataset.service;
}));

document.getElementById('serviceForm').addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  const lines = [
    'Hello NL Digital Labs Center, I would like to request a service.',
    '',
    `Name: ${data.get('name')}`,
    `Phone/WhatsApp: ${data.get('phone')}`,
    `Service: ${data.get('service')}`,
    `Description: ${data.get('description')}`,
    `Deadline: ${data.get('deadline') || 'Not specified'}`,
    `Email: ${data.get('email') || 'Not provided'}`
  ];
  const message = lines.join('\n');
  document.getElementById('requestStatus').textContent = 'Opening WhatsApp with your request details. Please review and press Send in WhatsApp to submit.';
  window.open('https://wa.me/256768249632?text=' + encodeURIComponent(message), '_blank', 'noopener,noreferrer');
});

document.getElementById('feedbackForm').addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  const subject = `NL Digital Labs website feedback: ${data.get('type')}`;
  const body = `Name: ${data.get('name') || 'Not provided'}\nFeedback type: ${data.get('type')}\n\nMessage:\n${data.get('message')}`;
  document.getElementById('feedbackStatus').textContent = 'Opening your email app with the feedback. Please review and send the email to complete submission.';
  window.location.href = 'mailto:nuwaherezalevi2@gmail.com?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
});